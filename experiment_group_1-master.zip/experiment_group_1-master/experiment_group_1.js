﻿/*************************** 
 * Experiment_Group_1 Test *
 ***************************/

import { PsychoJS } from './lib/core-2021.1.4.js';
import * as core from './lib/core-2021.1.4.js';
import { TrialHandler } from './lib/data-2021.1.4.js';
import { Scheduler } from './lib/util-2021.1.4.js';
import * as visual from './lib/visual-2021.1.4.js';
import * as sound from './lib/sound-2021.1.4.js';
import * as util from './lib/util-2021.1.4.js';
//some handy aliases as in the psychopy scripts;
const { abs, sin, cos, PI: pi, sqrt } = Math;
const { round } = util;

// init psychoJS:
const psychoJS = new PsychoJS({
  debug: true
});

// open window:
psychoJS.openWindow({
  fullscr: true,
  color: new util.Color([1, 1, 1]),
  units: 'height',
  waitBlanking: true
});

// store info about the experiment session:
let expName = 'experiment_group_1';  // from the Builder filename that created this script
let expInfo = {'Prolific ID': '', 'fontSize': '0.03'};

// Start code blocks for 'Before Experiment'
// schedule the experiment:
psychoJS.schedule(psychoJS.gui.DlgFromDict({
  dictionary: expInfo,
  title: expName
}));

const flowScheduler = new Scheduler(psychoJS);
const dialogCancelScheduler = new Scheduler(psychoJS);
psychoJS.scheduleCondition(function() { return (psychoJS.gui.dialogComponent.button === 'OK'); }, flowScheduler, dialogCancelScheduler);

// flowScheduler gets run if the participants presses OK
flowScheduler.add(updateInfo); // add timeStamp
flowScheduler.add(experimentInit);
flowScheduler.add(HelloRoutineBegin());
flowScheduler.add(HelloRoutineEachFrame());
flowScheduler.add(HelloRoutineEnd());
const come_back_infconsLoopScheduler = new Scheduler(psychoJS);
flowScheduler.add(come_back_infconsLoopBegin, come_back_infconsLoopScheduler);
flowScheduler.add(come_back_infconsLoopScheduler);
flowScheduler.add(come_back_infconsLoopEnd);
flowScheduler.add(welcome_mexRoutineBegin());
flowScheduler.add(welcome_mexRoutineEachFrame());
flowScheduler.add(welcome_mexRoutineEnd());
const come_backLoopScheduler = new Scheduler(psychoJS);
flowScheduler.add(come_backLoopBegin, come_backLoopScheduler);
flowScheduler.add(come_backLoopScheduler);
flowScheduler.add(come_backLoopEnd);
const trialsLoopScheduler = new Scheduler(psychoJS);
flowScheduler.add(trialsLoopBegin, trialsLoopScheduler);
flowScheduler.add(trialsLoopScheduler);
flowScheduler.add(trialsLoopEnd);
flowScheduler.add(start_expRoutineBegin());
flowScheduler.add(start_expRoutineEachFrame());
flowScheduler.add(start_expRoutineEnd());
const trials_testLoopScheduler = new Scheduler(psychoJS);
flowScheduler.add(trials_testLoopBegin, trials_testLoopScheduler);
flowScheduler.add(trials_testLoopScheduler);
flowScheduler.add(trials_testLoopEnd);
flowScheduler.add(final_commentsRoutineBegin());
flowScheduler.add(final_commentsRoutineEachFrame());
flowScheduler.add(final_commentsRoutineEnd());
flowScheduler.add(thanks_messageRoutineBegin());
flowScheduler.add(thanks_messageRoutineEachFrame());
flowScheduler.add(thanks_messageRoutineEnd());
flowScheduler.add(quitPsychoJS, '', true);

// quit if user presses Cancel in dialog box:
dialogCancelScheduler.add(quitPsychoJS, '', false);

psychoJS.start({
  expName: expName,
  expInfo: expInfo,
  resources: [
    {'name': 'imagesExp/2360492_1667988_singleton_obj.png', 'path': 'imagesExp/2360492_1667988_singleton_obj.png'},
    {'name': 'imagesExp/2316639_3414850_singleton_obj.png', 'path': 'imagesExp/2316639_3414850_singleton_obj.png'},
    {'name': 'imagesExp/2408164_266906_supercat_unique.png', 'path': 'imagesExp/2408164_266906_supercat_unique.png'},
    {'name': 'imagesExp/2399395_1169997_seed_ambiguous.png', 'path': 'imagesExp/2399395_1169997_seed_ambiguous.png'},
    {'name': 'imagesExp/2339899_3691812_singleton_obj.png', 'path': 'imagesExp/2339899_3691812_singleton_obj.png'},
    {'name': 'imagesExp/2366674_1665694_singleton_obj.png', 'path': 'imagesExp/2366674_1665694_singleton_obj.png'},
    {'name': 'InfCon-2.png', 'path': 'InfCon-2.png'},
    {'name': 'test_familiarity.xlsx', 'path': 'test_familiarity.xlsx'},
    {'name': 'imagesExp/2393599_1218536_singleton_obj.png', 'path': 'imagesExp/2393599_1218536_singleton_obj.png'},
    {'name': 'imagesExp/61528_1059950_singleton_obj.png', 'path': 'imagesExp/61528_1059950_singleton_obj.png'},
    {'name': 'imagesExp/2323615_2803182_singleton_obj.png', 'path': 'imagesExp/2323615_2803182_singleton_obj.png'},
    {'name': 'loopTemplate1.xlsx', 'path': 'loopTemplate1.xlsx'},
    {'name': 'imagesExp/2342115_937116_singleton_obj.png', 'path': 'imagesExp/2342115_937116_singleton_obj.png'},
    {'name': 'imagesExp/2392690_478027_singleton_obj.png', 'path': 'imagesExp/2392690_478027_singleton_obj.png'},
    {'name': 'imagesExp/2382751_1326446_singleton_obj.png', 'path': 'imagesExp/2382751_1326446_singleton_obj.png'},
    {'name': 'imagesExp/2347744_3609431_supercat_ambiguous.png', 'path': 'imagesExp/2347744_3609431_supercat_ambiguous.png'},
    {'name': 'imagesExp/2348089_2328048_seed_ambiguous.png', 'path': 'imagesExp/2348089_2328048_seed_ambiguous.png'},
    {'name': 'imagesExp/2406730_291017_supercat_ambiguous.png', 'path': 'imagesExp/2406730_291017_supercat_ambiguous.png'},
    {'name': 'imagesExp/2321096_1048648_singleton_obj.png', 'path': 'imagesExp/2321096_1048648_singleton_obj.png'},
    {'name': 'imagesExp/2338913_2350640_seed_ambiguous.png', 'path': 'imagesExp/2338913_2350640_seed_ambiguous.png'},
    {'name': 'imagesExp/2659_1550847_seed_ambiguous.png', 'path': 'imagesExp/2659_1550847_seed_ambiguous.png'},
    {'name': 'imagesExp/2349587_2162340_seed_ambiguous.png', 'path': 'imagesExp/2349587_2162340_seed_ambiguous.png'},
    {'name': 'imagesExp/2326371_982416_singleton_obj.png', 'path': 'imagesExp/2326371_982416_singleton_obj.png'},
    {'name': 'imagesExp/1159815_1039917_singleton_obj.png', 'path': 'imagesExp/1159815_1039917_singleton_obj.png'},
    {'name': 'imagesExp/2315438_2769047_singleton_obj.png', 'path': 'imagesExp/2315438_2769047_singleton_obj.png'},
    {'name': 'imagesExp/2387704_511620_seed_ambiguous.png', 'path': 'imagesExp/2387704_511620_seed_ambiguous.png'},
    {'name': 'imagesExp/2223_1547851_singleton_obj.png', 'path': 'imagesExp/2223_1547851_singleton_obj.png'},
    {'name': 'imagesExp/2383809_530166_singleton_obj.png', 'path': 'imagesExp/2383809_530166_singleton_obj.png'},
    {'name': 'imagesExp/2408435_261856_singleton_obj.png', 'path': 'imagesExp/2408435_261856_singleton_obj.png'},
    {'name': 'imagesExp/2412295_3124334_singleton_obj.png', 'path': 'imagesExp/2412295_3124334_singleton_obj.png'},
    {'name': 'imagesExp/2381681_1334749_singleton_obj.png', 'path': 'imagesExp/2381681_1334749_singleton_obj.png'},
    {'name': 'imagesExp/2343423_2346260_singleton_obj.png', 'path': 'imagesExp/2343423_2346260_singleton_obj.png'},
    {'name': 'imagesExp/2365657_1711579_seed_ambiguous.png', 'path': 'imagesExp/2365657_1711579_seed_ambiguous.png'},
    {'name': 'imagesExp/2343667_3637575_singleton_obj.png', 'path': 'imagesExp/2343667_3637575_singleton_obj.png'},
    {'name': 'imagesExp/2358126_805887_singleton_obj.png', 'path': 'imagesExp/2358126_805887_singleton_obj.png'},
    {'name': 'imagesExp/2393947_3824340_singleton_obj.png', 'path': 'imagesExp/2393947_3824340_singleton_obj.png'},
    {'name': 'InfCon-1.png', 'path': 'InfCon-1.png'},
    {'name': 'imagesExp/2334503_3676990_singleton_obj.png', 'path': 'imagesExp/2334503_3676990_singleton_obj.png'},
    {'name': 'imagesExp/2348007_1814723_seed_ambiguous.png', 'path': 'imagesExp/2348007_1814723_seed_ambiguous.png'},
    {'name': 'imagesExp/2321823_1047126_singleton_obj.png', 'path': 'imagesExp/2321823_1047126_singleton_obj.png'},
    {'name': 'imagesExp/2379467_1357311_singleton_obj.png', 'path': 'imagesExp/2379467_1357311_singleton_obj.png'},
    {'name': 'imagesExp/2372413_592041_singleton_obj.png', 'path': 'imagesExp/2372413_592041_singleton_obj.png'},
    {'name': 'imagesExp/2361711_3530910_supercat_unique.png', 'path': 'imagesExp/2361711_3530910_supercat_unique.png'},
    {'name': 'imagesExp/2411526_3813674_supercat_unique.png', 'path': 'imagesExp/2411526_3813674_supercat_unique.png'},
    {'name': 'imagesExp/2343847_2378278_singleton_obj.png', 'path': 'imagesExp/2343847_2378278_singleton_obj.png'},
    {'name': 'imagesExp/2331519_971735_singleton_obj.png', 'path': 'imagesExp/2331519_971735_singleton_obj.png'},
    {'name': 'imagesExp/2417219_3044499_singleton_obj.png', 'path': 'imagesExp/2417219_3044499_singleton_obj.png'},
    {'name': 'imagesExp/2353602_844601_singleton_obj.png', 'path': 'imagesExp/2353602_844601_singleton_obj.png'}
  ]
});

psychoJS.experimentLogger.setLevel(core.Logger.ServerLevel.DEBUG);


var frameDur;
function updateInfo() {
  expInfo['date'] = util.MonotonicClock.getDateStr();  // add a simple timestamp
  expInfo['expName'] = expName;
  expInfo['psychopyVersion'] = '2021.1.4';
  expInfo['OS'] = window.navigator.platform;

  // store frame rate of monitor if we can measure it successfully
  expInfo['frameRate'] = psychoJS.window.getActualFrameRate();
  if (typeof expInfo['frameRate'] !== 'undefined')
    frameDur = 1.0 / Math.round(expInfo['frameRate']);
  else
    frameDur = 1.0 / 60.0; // couldn't get a reliable measure so guess

  // add info from the URL:
  util.addInfoFromUrl(expInfo);
  psychoJS.setRedirectUrls('https://app.prolific.co/submissions/complete?cc=D6CB560C', '');

  return Scheduler.Event.NEXT;
}


var HelloClock;
var hello_text;
var key_resp_13;
var Informed_consent_1Clock;
var image_informed_consent_1;
var key_resp_11;
var go_on_2;
var Informed_consent_2Clock;
var image_informed_consent_2;
var key_resp_12;
var go_on_3;
var left_arrow_2;
var key_resp_14;
var welcome_mexClock;
var welcome_text;
var key_resp_3;
var general_infoClock;
var intro_text;
var key_resp_4;
var go_on;
var text_typicality;
var text_sliding_scale;
var specific_instructionsClock;
var text_instructions;
var key_resp;
var space_go_on;
var left_arrow;
var key_resp_9;
var trialClock;
var image_2;
var slider_2;
var key_resp_6;
var text_4;
var once_judged;
var start_expClock;
var text_start_exp;
var key_resp_7;
var real_experimentClock;
var image_stimuli;
var slider;
var text;
var key_resp_2;
var once_judged_2;
var final_commentsClock;
var leave_comment;
var textbox;
var rigth_arrow;
var end_experiment;
var thanks_messageClock;
var thanks_text;
var key_resp_10;
var globalClock;
var routineTimer;
function experimentInit() {
  // Initialize components for Routine "Hello"
  HelloClock = new util.Clock();
  hello_text = new visual.TextStim({
    win: psychoJS.window,
    name: 'hello_text',
    text: 'Welcome!\n\nRead carefully the informed consent form on the next two pages.\n\nWhenever you are ready, follow the instructions to start. \n\nNow, press space to go on.',
    font: 'Arial',
    units: undefined, 
    pos: [0, 0], height: 0.05,  wrapWidth: undefined, ori: 0.0,
    color: new util.Color('black'),  opacity: undefined,
    depth: 0.0 
  });
  
  key_resp_13 = new core.Keyboard({psychoJS: psychoJS, clock: new util.Clock(), waitForStart: true});
  
  // Initialize components for Routine "Informed_consent_1"
  Informed_consent_1Clock = new util.Clock();
  image_informed_consent_1 = new visual.ImageStim({
    win : psychoJS.window,
    name : 'image_informed_consent_1', units : undefined, 
    image : 'InfCon-1.png', mask : undefined,
    ori : 0.0, pos : [0, 0], size : [1.4, 0.9],
    color : new util.Color([1, 1, 1]), opacity : undefined,
    flipHoriz : false, flipVert : false,
    texRes : 128.0, interpolate : true, depth : 0.0 
  });
  key_resp_11 = new core.Keyboard({psychoJS: psychoJS, clock: new util.Clock(), waitForStart: true});
  
  go_on_2 = new visual.TextStim({
    win: psychoJS.window,
    name: 'go_on_2',
    text: 'Press space to go on',
    font: 'Arial',
    units: undefined, 
    pos: [0.6, (- 0.4)], height: 0.03,  wrapWidth: undefined, ori: 0.0,
    color: new util.Color('red'),  opacity: undefined,
    depth: -2.0 
  });
  
  // Initialize components for Routine "Informed_consent_2"
  Informed_consent_2Clock = new util.Clock();
  image_informed_consent_2 = new visual.ImageStim({
    win : psychoJS.window,
    name : 'image_informed_consent_2', units : undefined, 
    image : 'InfCon-2.png', mask : undefined,
    ori : 0.0, pos : [0, 0], size : [1.4, 0.9],
    color : new util.Color([1, 1, 1]), opacity : undefined,
    flipHoriz : false, flipVert : false,
    texRes : 128.0, interpolate : true, depth : 0.0 
  });
  key_resp_12 = new core.Keyboard({psychoJS: psychoJS, clock: new util.Clock(), waitForStart: true});
  
  go_on_3 = new visual.TextStim({
    win: psychoJS.window,
    name: 'go_on_3',
    text: 'Press space \nto start \nthe experiment',
    font: 'Arial',
    units: undefined, 
    pos: [0.6, (- 0.4)], height: 0.03,  wrapWidth: undefined, ori: 0.0,
    color: new util.Color('red'),  opacity: undefined,
    depth: -2.0 
  });
  
  left_arrow_2 = new visual.TextStim({
    win: psychoJS.window,
    name: 'left_arrow_2',
    text: 'Press \nleft arrow\nto come back',
    font: 'Arial',
    units: undefined, 
    pos: [0.3, (- 0.4)], height: 0.03,  wrapWidth: undefined, ori: 0.0,
    color: new util.Color('red'),  opacity: undefined,
    depth: -4.0 
  });
  
  key_resp_14 = new core.Keyboard({psychoJS: psychoJS, clock: new util.Clock(), waitForStart: true});
  
  // Initialize components for Routine "welcome_mex"
  welcome_mexClock = new util.Clock();
  welcome_text = new visual.TextStim({
    win: psychoJS.window,
    name: 'welcome_text',
    text: 'Ok, let’s start! \n \npress space to go on',
    font: 'Arial',
    units: undefined, 
    pos: [0, 0], height: 0.1,  wrapWidth: undefined, ori: 0.0,
    color: new util.Color('black'),  opacity: undefined,
    depth: 0.0 
  });
  
  key_resp_3 = new core.Keyboard({psychoJS: psychoJS, clock: new util.Clock(), waitForStart: true});
  
  // Initialize components for Routine "general_info"
  general_infoClock = new util.Clock();
  intro_text = new visual.TextStim({
    win: psychoJS.window,
    name: 'intro_text',
    text: 'GENERAL INFORMATION\n\nIn this task you will be given a series of images. \n\nAfter one second, a word indicating a category will appear below each image. \n\nYour task is to evaluate how typical the item inside the red bounding box is as an example of the category named by the word. \n\nThere is no right or wrong answer. \nTake your time to rate but do not overthink! \n\nNow, take a minute to understand what we mean with the term “typicality”. \n',
    font: 'Arial',
    units: undefined, 
    pos: [(- 0.6), (+ 0.2)], height: 0.03,  wrapWidth: undefined, ori: 0.0,
    color: new util.Color('black'),  opacity: undefined,
    depth: 0.0 
  });
  
  key_resp_4 = new core.Keyboard({psychoJS: psychoJS, clock: new util.Clock(), waitForStart: true});
  
  go_on = new visual.TextStim({
    win: psychoJS.window,
    name: 'go_on',
    text: 'Press space \nto go on',
    font: 'Arial',
    units: undefined, 
    pos: [(+ 0.6), (- 0.4)], height: 0.03,  wrapWidth: undefined, ori: 0.0,
    color: new util.Color('red'),  opacity: undefined,
    depth: -3.0 
  });
  
  text_typicality = new visual.TextStim({
    win: psychoJS.window,
    name: 'text_typicality',
    text: 'Typicality judgments can vary, because items can be considered better or worse members of a category.\n\n— An item is TYPICAL of a category if it represents a good example of that category\n\n— An item is NOT TYPICAL of a category if it is a poor example of that category\n',
    font: 'Arial',
    units: undefined, 
    pos: [(- 0.6), (- 0.2)], height: 0.03,  wrapWidth: undefined, ori: 0.0,
    color: new util.Color('blue'),  opacity: undefined,
    depth: -4.0 
  });
  
  text_sliding_scale = new visual.TextStim({
    win: psychoJS.window,
    name: 'text_sliding_scale',
    text: 'Thus, we give you a sliding scale to indicate your judgment ranging from NOT TYPICAL AT ALL if you think the item is a very poor example of the category to VERY TYPICAL if you think it is a very good example.',
    font: 'Arial',
    units: undefined, 
    pos: [(- 0.6), (- 0.4)], height: 0.03,  wrapWidth: undefined, ori: 0.0,
    color: new util.Color('black'),  opacity: undefined,
    depth: -5.0 
  });
  
  // Initialize components for Routine "specific_instructions"
  specific_instructionsClock = new util.Clock();
  text_instructions = new visual.TextStim({
    win: psychoJS.window,
    name: 'text_instructions',
    text: 'SPECIFIC INSTRUCTIONS\n\nFocus on the target item inside the red bounding box.\nOnce the word category appears below, rate:\n\nHow typical is the item for the category?\n\nPress on the slider bar to make the square marker appear  and set it where you feel your rating should go. \n\nFeel free to move the marker back and forth.\n\nOnce you have judged, press space to go on.\n\nBefore the experiment starts, you can familiarize yourself with the task with 2 examples.\n\nRemember: \nThere is no right answer. Take your time to judge but don’t overthink.\n',
    font: 'Arial',
    units: undefined, 
    pos: [(- 0.6), 0], height: 0.03,  wrapWidth: undefined, ori: 0.0,
    color: new util.Color('Black'),  opacity: undefined,
    depth: 0.0 
  });
  
  key_resp = new core.Keyboard({psychoJS: psychoJS, clock: new util.Clock(), waitForStart: true});
  
  space_go_on = new visual.TextStim({
    win: psychoJS.window,
    name: 'space_go_on',
    text: 'Press space\nto start the trial',
    font: 'Arial',
    units: undefined, 
    pos: [(+ 0.4), (- 0.4)], height: 0.03,  wrapWidth: undefined, ori: 0.0,
    color: new util.Color('red'),  opacity: undefined,
    depth: -3.0 
  });
  
  left_arrow = new visual.TextStim({
    win: psychoJS.window,
    name: 'left_arrow',
    text: 'Press left arrow\nto come back',
    font: 'Arial',
    units: undefined, 
    pos: [(- 0.4), (- 0.4)], height: 0.03,  wrapWidth: undefined, ori: 0.0,
    color: new util.Color('red'),  opacity: undefined,
    depth: -4.0 
  });
  
  key_resp_9 = new core.Keyboard({psychoJS: psychoJS, clock: new util.Clock(), waitForStart: true});
  
  // Initialize components for Routine "trial"
  trialClock = new util.Clock();
  image_2 = new visual.ImageStim({
    win : psychoJS.window,
    name : 'image_2', units : undefined, 
    image : undefined, mask : undefined,
    ori : 0.0, pos : [0, 0.2], size : [0.6, 0.5],
    color : new util.Color([1, 1, 1]), opacity : undefined,
    flipHoriz : false, flipVert : false,
    texRes : 128.0, interpolate : true, depth : 0.0 
  });
  slider_2 = new visual.Slider({
    win: psychoJS.window, name: 'slider_2',
    size: [0.5, 0.03], pos: [0, (- 0.2)], units: 'height',
    labels: ["not typical at all", "very typical"], ticks: [1, 20],
    granularity: 0.0, style: ["SLIDER", "TRIANGLE_MARKER"],
    color: new util.Color('Black'), 
    fontFamily: 'Open Sans', bold: true, italic: false, depth: -1, 
    flip: false,
  });
  
  key_resp_6 = new core.Keyboard({psychoJS: psychoJS, clock: new util.Clock(), waitForStart: true});
  
  text_4 = new visual.TextStim({
    win: psychoJS.window,
    name: 'text_4',
    text: '',
    font: 'Arial',
    units: undefined, 
    pos: [0, (- 0.1)], height: 0.07,  wrapWidth: undefined, ori: 0.0,
    color: new util.Color('black'),  opacity: undefined,
    depth: -3.0 
  });
  
  once_judged = new visual.TextStim({
    win: psychoJS.window,
    name: 'once_judged',
    text: 'once you have judged, press space ',
    font: 'Arial',
    units: undefined, 
    pos: [0, (- 0.4)], height: 0.03,  wrapWidth: undefined, ori: 0.0,
    color: new util.Color('black'),  opacity: undefined,
    depth: -4.0 
  });
  
  // Initialize components for Routine "start_exp"
  start_expClock = new util.Clock();
  text_start_exp = new visual.TextStim({
    win: psychoJS.window,
    name: 'text_start_exp',
    text: 'Ready? \n\nOnce you press space the experiment starts',
    font: 'Arial',
    units: undefined, 
    pos: [0, 0], height: 0.08,  wrapWidth: undefined, ori: 0.0,
    color: new util.Color('black'),  opacity: undefined,
    depth: 0.0 
  });
  
  key_resp_7 = new core.Keyboard({psychoJS: psychoJS, clock: new util.Clock(), waitForStart: true});
  
  // Initialize components for Routine "real_experiment"
  real_experimentClock = new util.Clock();
  image_stimuli = new visual.ImageStim({
    win : psychoJS.window,
    name : 'image_stimuli', units : undefined, 
    image : undefined, mask : undefined,
    ori : 0.0, pos : [0, 0.2], size : [0.6, 0.5],
    color : new util.Color([1, 1, 1]), opacity : undefined,
    flipHoriz : false, flipVert : false,
    texRes : 128.0, interpolate : true, depth : 0.0 
  });
  slider = new visual.Slider({
    win: psychoJS.window, name: 'slider',
    size: [0.5, 0.03], pos: [0, (- 0.2)], units: 'height',
    labels: ["not typical at all", "very typical"], ticks: [1, 20],
    granularity: 1.0, style: ["SLIDER", "TRIANGLE_MARKER"],
    color: new util.Color('black'), 
    fontFamily: 'Arial', bold: true, italic: false, depth: -1, 
    flip: false,
  });
  
  text = new visual.TextStim({
    win: psychoJS.window,
    name: 'text',
    text: '',
    font: 'Arial',
    units: undefined, 
    pos: [0, (- 0.1)], height: 0.07,  wrapWidth: undefined, ori: 0.0,
    color: new util.Color('black'),  opacity: undefined,
    depth: -2.0 
  });
  
  key_resp_2 = new core.Keyboard({psychoJS: psychoJS, clock: new util.Clock(), waitForStart: true});
  
  once_judged_2 = new visual.TextStim({
    win: psychoJS.window,
    name: 'once_judged_2',
    text: 'once you have judged, press space ',
    font: 'Arial',
    units: undefined, 
    pos: [0, (- 0.4)], height: 0.03,  wrapWidth: undefined, ori: 0.0,
    color: new util.Color('black'),  opacity: undefined,
    depth: -4.0 
  });
  
  // Initialize components for Routine "final_comments"
  final_commentsClock = new util.Clock();
  leave_comment = new visual.TextStim({
    win: psychoJS.window,
    name: 'leave_comment',
    text: 'Almost done…\n\n… feel free to leave any comments/thoughts about the task or the stimuli\n',
    font: 'Arial',
    units: undefined, 
    pos: [0, (+ 0.2)], height: 0.05,  wrapWidth: undefined, ori: 0.0,
    color: new util.Color('black'),  opacity: undefined,
    depth: 0.0 
  });
  
  textbox = new visual.TextBox({
    win: psychoJS.window,
    name: 'textbox',
    text: '',
    font: 'Open Sans',
    pos: [(- 0.1), (- 0.2)], letterHeight: 0.05,
    size: undefined,  units: undefined, 
    color: 'red', colorSpace: 'rgb',
    fillColor: undefined, borderColor: 'Black',
    bold: false, italic: false,
    opacity: undefined,
    padding: undefined,
    editable: true,
    multiline: true,
    anchor: 'center',
    depth: -1.0 
  });
  
  rigth_arrow = new visual.TextStim({
    win: psychoJS.window,
    name: 'rigth_arrow',
    text: 'Press the right arrow to go on',
    font: 'Arial',
    units: undefined, 
    pos: [0, (- 0.4)], height: 0.05,  wrapWidth: undefined, ori: 0.0,
    color: new util.Color('black'),  opacity: undefined,
    depth: -2.0 
  });
  
  end_experiment = new core.Keyboard({psychoJS: psychoJS, clock: new util.Clock(), waitForStart: true});
  
  // Initialize components for Routine "thanks_message"
  thanks_messageClock = new util.Clock();
  thanks_text = new visual.TextStim({
    win: psychoJS.window,
    name: 'thanks_text',
    text: 'Thanks, done!\n\npress space to end the expriment',
    font: 'Arial',
    units: undefined, 
    pos: [0, 0], height: 0.05,  wrapWidth: undefined, ori: 0.0,
    color: new util.Color('black'),  opacity: undefined,
    depth: 0.0 
  });
  
  key_resp_10 = new core.Keyboard({psychoJS: psychoJS, clock: new util.Clock(), waitForStart: true});
  
  // Create some handy timers
  globalClock = new util.Clock();  // to track the time since experiment started
  routineTimer = new util.CountdownTimer();  // to track time remaining of each (non-slip) routine
  
  return Scheduler.Event.NEXT;
}


var t;
var frameN;
var continueRoutine;
var _key_resp_13_allKeys;
var HelloComponents;
function HelloRoutineBegin(snapshot) {
  return function () {
    //------Prepare to start Routine 'Hello'-------
    t = 0;
    HelloClock.reset(); // clock
    frameN = -1;
    continueRoutine = true; // until we're told otherwise
    // update component parameters for each repeat
    key_resp_13.keys = undefined;
    key_resp_13.rt = undefined;
    _key_resp_13_allKeys = [];
    // keep track of which components have finished
    HelloComponents = [];
    HelloComponents.push(hello_text);
    HelloComponents.push(key_resp_13);
    
    for (const thisComponent of HelloComponents)
      if ('status' in thisComponent)
        thisComponent.status = PsychoJS.Status.NOT_STARTED;
    return Scheduler.Event.NEXT;
  }
}


function HelloRoutineEachFrame(snapshot) {
  return function () {
    //------Loop for each frame of Routine 'Hello'-------
    // get current time
    t = HelloClock.getTime();
    frameN = frameN + 1;// number of completed frames (so 0 is the first frame)
    // update/draw components on each frame
    
    // *hello_text* updates
    if (t >= 0.0 && hello_text.status === PsychoJS.Status.NOT_STARTED) {
      // keep track of start time/frame for later
      hello_text.tStart = t;  // (not accounting for frame time here)
      hello_text.frameNStart = frameN;  // exact frame index
      
      hello_text.setAutoDraw(true);
    }

    
    // *key_resp_13* updates
    if (t >= 0.0 && key_resp_13.status === PsychoJS.Status.NOT_STARTED) {
      // keep track of start time/frame for later
      key_resp_13.tStart = t;  // (not accounting for frame time here)
      key_resp_13.frameNStart = frameN;  // exact frame index
      
      // keyboard checking is just starting
      psychoJS.window.callOnFlip(function() { key_resp_13.clock.reset(); });  // t=0 on next screen flip
      psychoJS.window.callOnFlip(function() { key_resp_13.start(); }); // start on screen flip
      psychoJS.window.callOnFlip(function() { key_resp_13.clearEvents(); });
    }

    if (key_resp_13.status === PsychoJS.Status.STARTED) {
      let theseKeys = key_resp_13.getKeys({keyList: ['space'], waitRelease: false});
      _key_resp_13_allKeys = _key_resp_13_allKeys.concat(theseKeys);
      if (_key_resp_13_allKeys.length > 0) {
        key_resp_13.keys = _key_resp_13_allKeys[_key_resp_13_allKeys.length - 1].name;  // just the last key pressed
        key_resp_13.rt = _key_resp_13_allKeys[_key_resp_13_allKeys.length - 1].rt;
        // a response ends the routine
        continueRoutine = false;
      }
    }
    
    // check for quit (typically the Esc key)
    if (psychoJS.experiment.experimentEnded || psychoJS.eventManager.getKeys({keyList:['escape']}).length > 0) {
      return quitPsychoJS('The [Escape] key was pressed. Goodbye!', false);
    }
    
    // check if the Routine should terminate
    if (!continueRoutine) {  // a component has requested a forced-end of Routine
      return Scheduler.Event.NEXT;
    }
    
    continueRoutine = false;  // reverts to True if at least one component still running
    for (const thisComponent of HelloComponents)
      if ('status' in thisComponent && thisComponent.status !== PsychoJS.Status.FINISHED) {
        continueRoutine = true;
        break;
      }
    
    // refresh the screen if continuing
    if (continueRoutine) {
      return Scheduler.Event.FLIP_REPEAT;
    } else {
      return Scheduler.Event.NEXT;
    }
  };
}


function HelloRoutineEnd(snapshot) {
  return function () {
    //------Ending Routine 'Hello'-------
    for (const thisComponent of HelloComponents) {
      if (typeof thisComponent.setAutoDraw === 'function') {
        thisComponent.setAutoDraw(false);
      }
    }
    key_resp_13.stop();
    // the Routine "Hello" was not non-slip safe, so reset the non-slip timer
    routineTimer.reset();
    
    return Scheduler.Event.NEXT;
  };
}


var come_back_infcons;
var currentLoop;
function come_back_infconsLoopBegin(come_back_infconsLoopScheduler) {
  // set up handler to look after randomisation of conditions etc
  come_back_infcons = new TrialHandler({
    psychoJS: psychoJS,
    nReps: 1000, method: TrialHandler.Method.RANDOM,
    extraInfo: expInfo, originPath: undefined,
    trialList: undefined,
    seed: undefined, name: 'come_back_infcons'
  });
  psychoJS.experiment.addLoop(come_back_infcons); // add the loop to the experiment
  currentLoop = come_back_infcons;  // we're now the current loop

  // Schedule all the trials in the trialList:
  for (const thisCome_back_infcon of come_back_infcons) {
    const snapshot = come_back_infcons.getSnapshot();
    come_back_infconsLoopScheduler.add(importConditions(snapshot));
    come_back_infconsLoopScheduler.add(Informed_consent_1RoutineBegin(snapshot));
    come_back_infconsLoopScheduler.add(Informed_consent_1RoutineEachFrame(snapshot));
    come_back_infconsLoopScheduler.add(Informed_consent_1RoutineEnd(snapshot));
    come_back_infconsLoopScheduler.add(Informed_consent_2RoutineBegin(snapshot));
    come_back_infconsLoopScheduler.add(Informed_consent_2RoutineEachFrame(snapshot));
    come_back_infconsLoopScheduler.add(Informed_consent_2RoutineEnd(snapshot));
    come_back_infconsLoopScheduler.add(endLoopIteration(come_back_infconsLoopScheduler, snapshot));
  }

  return Scheduler.Event.NEXT;
}


function come_back_infconsLoopEnd() {
  psychoJS.experiment.removeLoop(come_back_infcons);

  return Scheduler.Event.NEXT;
}


var come_back;
function come_backLoopBegin(come_backLoopScheduler) {
  // set up handler to look after randomisation of conditions etc
  come_back = new TrialHandler({
    psychoJS: psychoJS,
    nReps: 1000, method: TrialHandler.Method.RANDOM,
    extraInfo: expInfo, originPath: undefined,
    trialList: undefined,
    seed: undefined, name: 'come_back'
  });
  psychoJS.experiment.addLoop(come_back); // add the loop to the experiment
  currentLoop = come_back;  // we're now the current loop

  // Schedule all the trials in the trialList:
  for (const thisCome_back of come_back) {
    const snapshot = come_back.getSnapshot();
    come_backLoopScheduler.add(importConditions(snapshot));
    come_backLoopScheduler.add(general_infoRoutineBegin(snapshot));
    come_backLoopScheduler.add(general_infoRoutineEachFrame(snapshot));
    come_backLoopScheduler.add(general_infoRoutineEnd(snapshot));
    come_backLoopScheduler.add(specific_instructionsRoutineBegin(snapshot));
    come_backLoopScheduler.add(specific_instructionsRoutineEachFrame(snapshot));
    come_backLoopScheduler.add(specific_instructionsRoutineEnd(snapshot));
    come_backLoopScheduler.add(endLoopIteration(come_backLoopScheduler, snapshot));
  }

  return Scheduler.Event.NEXT;
}


function come_backLoopEnd() {
  psychoJS.experiment.removeLoop(come_back);

  return Scheduler.Event.NEXT;
}


var trials;
function trialsLoopBegin(trialsLoopScheduler) {
  // set up handler to look after randomisation of conditions etc
  trials = new TrialHandler({
    psychoJS: psychoJS,
    nReps: 1, method: TrialHandler.Method.RANDOM,
    extraInfo: expInfo, originPath: undefined,
    trialList: 'test_familiarity.xlsx',
    seed: undefined, name: 'trials'
  });
  psychoJS.experiment.addLoop(trials); // add the loop to the experiment
  currentLoop = trials;  // we're now the current loop

  // Schedule all the trials in the trialList:
  for (const thisTrial of trials) {
    const snapshot = trials.getSnapshot();
    trialsLoopScheduler.add(importConditions(snapshot));
    trialsLoopScheduler.add(trialRoutineBegin(snapshot));
    trialsLoopScheduler.add(trialRoutineEachFrame(snapshot));
    trialsLoopScheduler.add(trialRoutineEnd(snapshot));
    trialsLoopScheduler.add(endLoopIteration(trialsLoopScheduler, snapshot));
  }

  return Scheduler.Event.NEXT;
}


function trialsLoopEnd() {
  psychoJS.experiment.removeLoop(trials);

  return Scheduler.Event.NEXT;
}


var trials_test;
function trials_testLoopBegin(trials_testLoopScheduler) {
  // set up handler to look after randomisation of conditions etc
  trials_test = new TrialHandler({
    psychoJS: psychoJS,
    nReps: 1, method: TrialHandler.Method.FULLRANDOM,
    extraInfo: expInfo, originPath: undefined,
    trialList: 'loopTemplate1.xlsx',
    seed: undefined, name: 'trials_test'
  });
  psychoJS.experiment.addLoop(trials_test); // add the loop to the experiment
  currentLoop = trials_test;  // we're now the current loop

  // Schedule all the trials in the trialList:
  for (const thisTrials_test of trials_test) {
    const snapshot = trials_test.getSnapshot();
    trials_testLoopScheduler.add(importConditions(snapshot));
    trials_testLoopScheduler.add(real_experimentRoutineBegin(snapshot));
    trials_testLoopScheduler.add(real_experimentRoutineEachFrame(snapshot));
    trials_testLoopScheduler.add(real_experimentRoutineEnd(snapshot));
    trials_testLoopScheduler.add(endLoopIteration(trials_testLoopScheduler, snapshot));
  }

  return Scheduler.Event.NEXT;
}


function trials_testLoopEnd() {
  psychoJS.experiment.removeLoop(trials_test);

  return Scheduler.Event.NEXT;
}


var _key_resp_11_allKeys;
var Informed_consent_1Components;
function Informed_consent_1RoutineBegin(snapshot) {
  return function () {
    //------Prepare to start Routine 'Informed_consent_1'-------
    t = 0;
    Informed_consent_1Clock.reset(); // clock
    frameN = -1;
    continueRoutine = true; // until we're told otherwise
    // update component parameters for each repeat
    key_resp_11.keys = undefined;
    key_resp_11.rt = undefined;
    _key_resp_11_allKeys = [];
    // keep track of which components have finished
    Informed_consent_1Components = [];
    Informed_consent_1Components.push(image_informed_consent_1);
    Informed_consent_1Components.push(key_resp_11);
    Informed_consent_1Components.push(go_on_2);
    
    for (const thisComponent of Informed_consent_1Components)
      if ('status' in thisComponent)
        thisComponent.status = PsychoJS.Status.NOT_STARTED;
    return Scheduler.Event.NEXT;
  }
}


function Informed_consent_1RoutineEachFrame(snapshot) {
  return function () {
    //------Loop for each frame of Routine 'Informed_consent_1'-------
    // get current time
    t = Informed_consent_1Clock.getTime();
    frameN = frameN + 1;// number of completed frames (so 0 is the first frame)
    // update/draw components on each frame
    
    // *image_informed_consent_1* updates
    if (t >= 0.0 && image_informed_consent_1.status === PsychoJS.Status.NOT_STARTED) {
      // keep track of start time/frame for later
      image_informed_consent_1.tStart = t;  // (not accounting for frame time here)
      image_informed_consent_1.frameNStart = frameN;  // exact frame index
      
      image_informed_consent_1.setAutoDraw(true);
    }

    
    // *key_resp_11* updates
    if (t >= 0.0 && key_resp_11.status === PsychoJS.Status.NOT_STARTED) {
      // keep track of start time/frame for later
      key_resp_11.tStart = t;  // (not accounting for frame time here)
      key_resp_11.frameNStart = frameN;  // exact frame index
      
      // keyboard checking is just starting
      psychoJS.window.callOnFlip(function() { key_resp_11.clock.reset(); });  // t=0 on next screen flip
      psychoJS.window.callOnFlip(function() { key_resp_11.start(); }); // start on screen flip
      psychoJS.window.callOnFlip(function() { key_resp_11.clearEvents(); });
    }

    if (key_resp_11.status === PsychoJS.Status.STARTED) {
      let theseKeys = key_resp_11.getKeys({keyList: ['space'], waitRelease: false});
      _key_resp_11_allKeys = _key_resp_11_allKeys.concat(theseKeys);
      if (_key_resp_11_allKeys.length > 0) {
        key_resp_11.keys = _key_resp_11_allKeys[_key_resp_11_allKeys.length - 1].name;  // just the last key pressed
        key_resp_11.rt = _key_resp_11_allKeys[_key_resp_11_allKeys.length - 1].rt;
        // a response ends the routine
        continueRoutine = false;
      }
    }
    
    
    // *go_on_2* updates
    if (t >= 1.0 && go_on_2.status === PsychoJS.Status.NOT_STARTED) {
      // keep track of start time/frame for later
      go_on_2.tStart = t;  // (not accounting for frame time here)
      go_on_2.frameNStart = frameN;  // exact frame index
      
      go_on_2.setAutoDraw(true);
    }

    // check for quit (typically the Esc key)
    if (psychoJS.experiment.experimentEnded || psychoJS.eventManager.getKeys({keyList:['escape']}).length > 0) {
      return quitPsychoJS('The [Escape] key was pressed. Goodbye!', false);
    }
    
    // check if the Routine should terminate
    if (!continueRoutine) {  // a component has requested a forced-end of Routine
      return Scheduler.Event.NEXT;
    }
    
    continueRoutine = false;  // reverts to True if at least one component still running
    for (const thisComponent of Informed_consent_1Components)
      if ('status' in thisComponent && thisComponent.status !== PsychoJS.Status.FINISHED) {
        continueRoutine = true;
        break;
      }
    
    // refresh the screen if continuing
    if (continueRoutine) {
      return Scheduler.Event.FLIP_REPEAT;
    } else {
      return Scheduler.Event.NEXT;
    }
  };
}


function Informed_consent_1RoutineEnd(snapshot) {
  return function () {
    //------Ending Routine 'Informed_consent_1'-------
    for (const thisComponent of Informed_consent_1Components) {
      if (typeof thisComponent.setAutoDraw === 'function') {
        thisComponent.setAutoDraw(false);
      }
    }
    psychoJS.experiment.addData('key_resp_11.keys', key_resp_11.keys);
    if (typeof key_resp_11.keys !== 'undefined') {  // we had a response
        psychoJS.experiment.addData('key_resp_11.rt', key_resp_11.rt);
        routineTimer.reset();
        }
    
    key_resp_11.stop();
    // the Routine "Informed_consent_1" was not non-slip safe, so reset the non-slip timer
    routineTimer.reset();
    
    return Scheduler.Event.NEXT;
  };
}


var _key_resp_12_allKeys;
var _key_resp_14_allKeys;
var Informed_consent_2Components;
function Informed_consent_2RoutineBegin(snapshot) {
  return function () {
    //------Prepare to start Routine 'Informed_consent_2'-------
    t = 0;
    Informed_consent_2Clock.reset(); // clock
    frameN = -1;
    continueRoutine = true; // until we're told otherwise
    // update component parameters for each repeat
    key_resp_12.keys = undefined;
    key_resp_12.rt = undefined;
    _key_resp_12_allKeys = [];
    key_resp_14.keys = undefined;
    key_resp_14.rt = undefined;
    _key_resp_14_allKeys = [];
    // keep track of which components have finished
    Informed_consent_2Components = [];
    Informed_consent_2Components.push(image_informed_consent_2);
    Informed_consent_2Components.push(key_resp_12);
    Informed_consent_2Components.push(go_on_3);
    Informed_consent_2Components.push(left_arrow_2);
    Informed_consent_2Components.push(key_resp_14);
    
    for (const thisComponent of Informed_consent_2Components)
      if ('status' in thisComponent)
        thisComponent.status = PsychoJS.Status.NOT_STARTED;
    return Scheduler.Event.NEXT;
  }
}


function Informed_consent_2RoutineEachFrame(snapshot) {
  return function () {
    //------Loop for each frame of Routine 'Informed_consent_2'-------
    // get current time
    t = Informed_consent_2Clock.getTime();
    frameN = frameN + 1;// number of completed frames (so 0 is the first frame)
    // update/draw components on each frame
    
    // *image_informed_consent_2* updates
    if (t >= 0.0 && image_informed_consent_2.status === PsychoJS.Status.NOT_STARTED) {
      // keep track of start time/frame for later
      image_informed_consent_2.tStart = t;  // (not accounting for frame time here)
      image_informed_consent_2.frameNStart = frameN;  // exact frame index
      
      image_informed_consent_2.setAutoDraw(true);
    }

    
    // *key_resp_12* updates
    if (t >= 0.0 && key_resp_12.status === PsychoJS.Status.NOT_STARTED) {
      // keep track of start time/frame for later
      key_resp_12.tStart = t;  // (not accounting for frame time here)
      key_resp_12.frameNStart = frameN;  // exact frame index
      
      // keyboard checking is just starting
      psychoJS.window.callOnFlip(function() { key_resp_12.clock.reset(); });  // t=0 on next screen flip
      psychoJS.window.callOnFlip(function() { key_resp_12.start(); }); // start on screen flip
      psychoJS.window.callOnFlip(function() { key_resp_12.clearEvents(); });
    }

    if (key_resp_12.status === PsychoJS.Status.STARTED) {
      let theseKeys = key_resp_12.getKeys({keyList: ['space'], waitRelease: false});
      _key_resp_12_allKeys = _key_resp_12_allKeys.concat(theseKeys);
      if (_key_resp_12_allKeys.length > 0) {
        key_resp_12.keys = _key_resp_12_allKeys[_key_resp_12_allKeys.length - 1].name;  // just the last key pressed
        key_resp_12.rt = _key_resp_12_allKeys[_key_resp_12_allKeys.length - 1].rt;
        // a response ends the routine
        continueRoutine = false;
      }
    }
    
    
    // *go_on_3* updates
    if (t >= 1.0 && go_on_3.status === PsychoJS.Status.NOT_STARTED) {
      // keep track of start time/frame for later
      go_on_3.tStart = t;  // (not accounting for frame time here)
      go_on_3.frameNStart = frameN;  // exact frame index
      
      go_on_3.setAutoDraw(true);
    }

    
    // *left_arrow_2* updates
    if (t >= 1.0 && left_arrow_2.status === PsychoJS.Status.NOT_STARTED) {
      // keep track of start time/frame for later
      left_arrow_2.tStart = t;  // (not accounting for frame time here)
      left_arrow_2.frameNStart = frameN;  // exact frame index
      
      left_arrow_2.setAutoDraw(true);
    }

    
    // *key_resp_14* updates
    if (t >= 0.0 && key_resp_14.status === PsychoJS.Status.NOT_STARTED) {
      // keep track of start time/frame for later
      key_resp_14.tStart = t;  // (not accounting for frame time here)
      key_resp_14.frameNStart = frameN;  // exact frame index
      
      // keyboard checking is just starting
      psychoJS.window.callOnFlip(function() { key_resp_14.clock.reset(); });  // t=0 on next screen flip
      psychoJS.window.callOnFlip(function() { key_resp_14.start(); }); // start on screen flip
      psychoJS.window.callOnFlip(function() { key_resp_14.clearEvents(); });
    }

    if (key_resp_14.status === PsychoJS.Status.STARTED) {
      let theseKeys = key_resp_14.getKeys({keyList: ['left'], waitRelease: false});
      _key_resp_14_allKeys = _key_resp_14_allKeys.concat(theseKeys);
      if (_key_resp_14_allKeys.length > 0) {
        key_resp_14.keys = _key_resp_14_allKeys[_key_resp_14_allKeys.length - 1].name;  // just the last key pressed
        key_resp_14.rt = _key_resp_14_allKeys[_key_resp_14_allKeys.length - 1].rt;
        // a response ends the routine
        continueRoutine = false;
      }
    }
    
    // check for quit (typically the Esc key)
    if (psychoJS.experiment.experimentEnded || psychoJS.eventManager.getKeys({keyList:['escape']}).length > 0) {
      return quitPsychoJS('The [Escape] key was pressed. Goodbye!', false);
    }
    
    // check if the Routine should terminate
    if (!continueRoutine) {  // a component has requested a forced-end of Routine
      return Scheduler.Event.NEXT;
    }
    
    continueRoutine = false;  // reverts to True if at least one component still running
    for (const thisComponent of Informed_consent_2Components)
      if ('status' in thisComponent && thisComponent.status !== PsychoJS.Status.FINISHED) {
        continueRoutine = true;
        break;
      }
    
    // refresh the screen if continuing
    if (continueRoutine) {
      return Scheduler.Event.FLIP_REPEAT;
    } else {
      return Scheduler.Event.NEXT;
    }
  };
}


function Informed_consent_2RoutineEnd(snapshot) {
  return function () {
    //------Ending Routine 'Informed_consent_2'-------
    for (const thisComponent of Informed_consent_2Components) {
      if (typeof thisComponent.setAutoDraw === 'function') {
        thisComponent.setAutoDraw(false);
      }
    }
    psychoJS.experiment.addData('key_resp_12.keys', key_resp_12.keys);
    if (typeof key_resp_12.keys !== 'undefined') {  // we had a response
        psychoJS.experiment.addData('key_resp_12.rt', key_resp_12.rt);
        routineTimer.reset();
        }
    
    key_resp_12.stop();
    if ((key_resp_12.keys === "space")) {
        come_back_infcons.finished = true;
    }
    
    psychoJS.experiment.addData('key_resp_14.keys', key_resp_14.keys);
    if (typeof key_resp_14.keys !== 'undefined') {  // we had a response
        psychoJS.experiment.addData('key_resp_14.rt', key_resp_14.rt);
        routineTimer.reset();
        }
    
    key_resp_14.stop();
    // the Routine "Informed_consent_2" was not non-slip safe, so reset the non-slip timer
    routineTimer.reset();
    
    return Scheduler.Event.NEXT;
  };
}


var _key_resp_3_allKeys;
var welcome_mexComponents;
function welcome_mexRoutineBegin(snapshot) {
  return function () {
    //------Prepare to start Routine 'welcome_mex'-------
    t = 0;
    welcome_mexClock.reset(); // clock
    frameN = -1;
    continueRoutine = true; // until we're told otherwise
    // update component parameters for each repeat
    key_resp_3.keys = undefined;
    key_resp_3.rt = undefined;
    _key_resp_3_allKeys = [];
    // keep track of which components have finished
    welcome_mexComponents = [];
    welcome_mexComponents.push(welcome_text);
    welcome_mexComponents.push(key_resp_3);
    
    for (const thisComponent of welcome_mexComponents)
      if ('status' in thisComponent)
        thisComponent.status = PsychoJS.Status.NOT_STARTED;
    return Scheduler.Event.NEXT;
  }
}


function welcome_mexRoutineEachFrame(snapshot) {
  return function () {
    //------Loop for each frame of Routine 'welcome_mex'-------
    // get current time
    t = welcome_mexClock.getTime();
    frameN = frameN + 1;// number of completed frames (so 0 is the first frame)
    // update/draw components on each frame
    
    // *welcome_text* updates
    if (t >= 0.0 && welcome_text.status === PsychoJS.Status.NOT_STARTED) {
      // keep track of start time/frame for later
      welcome_text.tStart = t;  // (not accounting for frame time here)
      welcome_text.frameNStart = frameN;  // exact frame index
      
      welcome_text.setAutoDraw(true);
    }

    
    // *key_resp_3* updates
    if (t >= 0.0 && key_resp_3.status === PsychoJS.Status.NOT_STARTED) {
      // keep track of start time/frame for later
      key_resp_3.tStart = t;  // (not accounting for frame time here)
      key_resp_3.frameNStart = frameN;  // exact frame index
      
      // keyboard checking is just starting
      psychoJS.window.callOnFlip(function() { key_resp_3.clock.reset(); });  // t=0 on next screen flip
      psychoJS.window.callOnFlip(function() { key_resp_3.start(); }); // start on screen flip
      psychoJS.window.callOnFlip(function() { key_resp_3.clearEvents(); });
    }

    if (key_resp_3.status === PsychoJS.Status.STARTED) {
      let theseKeys = key_resp_3.getKeys({keyList: ['space'], waitRelease: false});
      _key_resp_3_allKeys = _key_resp_3_allKeys.concat(theseKeys);
      if (_key_resp_3_allKeys.length > 0) {
        key_resp_3.keys = _key_resp_3_allKeys[_key_resp_3_allKeys.length - 1].name;  // just the last key pressed
        key_resp_3.rt = _key_resp_3_allKeys[_key_resp_3_allKeys.length - 1].rt;
        // a response ends the routine
        continueRoutine = false;
      }
    }
    
    // check for quit (typically the Esc key)
    if (psychoJS.experiment.experimentEnded || psychoJS.eventManager.getKeys({keyList:['escape']}).length > 0) {
      return quitPsychoJS('The [Escape] key was pressed. Goodbye!', false);
    }
    
    // check if the Routine should terminate
    if (!continueRoutine) {  // a component has requested a forced-end of Routine
      return Scheduler.Event.NEXT;
    }
    
    continueRoutine = false;  // reverts to True if at least one component still running
    for (const thisComponent of welcome_mexComponents)
      if ('status' in thisComponent && thisComponent.status !== PsychoJS.Status.FINISHED) {
        continueRoutine = true;
        break;
      }
    
    // refresh the screen if continuing
    if (continueRoutine) {
      return Scheduler.Event.FLIP_REPEAT;
    } else {
      return Scheduler.Event.NEXT;
    }
  };
}


function welcome_mexRoutineEnd(snapshot) {
  return function () {
    //------Ending Routine 'welcome_mex'-------
    for (const thisComponent of welcome_mexComponents) {
      if (typeof thisComponent.setAutoDraw === 'function') {
        thisComponent.setAutoDraw(false);
      }
    }
    key_resp_3.stop();
    // the Routine "welcome_mex" was not non-slip safe, so reset the non-slip timer
    routineTimer.reset();
    
    return Scheduler.Event.NEXT;
  };
}


var _key_resp_4_allKeys;
var general_infoComponents;
function general_infoRoutineBegin(snapshot) {
  return function () {
    //------Prepare to start Routine 'general_info'-------
    t = 0;
    general_infoClock.reset(); // clock
    frameN = -1;
    continueRoutine = true; // until we're told otherwise
    // update component parameters for each repeat
    key_resp_4.keys = undefined;
    key_resp_4.rt = undefined;
    _key_resp_4_allKeys = [];
    intro_text.setAlignHoriz('left');
    text_typicality.setAlignHoriz('left');
    text_sliding_scale.setAlignHoriz('left');
    // keep track of which components have finished
    general_infoComponents = [];
    general_infoComponents.push(intro_text);
    general_infoComponents.push(key_resp_4);
    general_infoComponents.push(go_on);
    general_infoComponents.push(text_typicality);
    general_infoComponents.push(text_sliding_scale);
    
    for (const thisComponent of general_infoComponents)
      if ('status' in thisComponent)
        thisComponent.status = PsychoJS.Status.NOT_STARTED;
    return Scheduler.Event.NEXT;
  }
}


function general_infoRoutineEachFrame(snapshot) {
  return function () {
    //------Loop for each frame of Routine 'general_info'-------
    // get current time
    t = general_infoClock.getTime();
    frameN = frameN + 1;// number of completed frames (so 0 is the first frame)
    // update/draw components on each frame
    
    // *intro_text* updates
    if (t >= 0.0 && intro_text.status === PsychoJS.Status.NOT_STARTED) {
      // keep track of start time/frame for later
      intro_text.tStart = t;  // (not accounting for frame time here)
      intro_text.frameNStart = frameN;  // exact frame index
      
      intro_text.setAutoDraw(true);
    }

    
    // *key_resp_4* updates
    if (t >= 0.0 && key_resp_4.status === PsychoJS.Status.NOT_STARTED) {
      // keep track of start time/frame for later
      key_resp_4.tStart = t;  // (not accounting for frame time here)
      key_resp_4.frameNStart = frameN;  // exact frame index
      
      // keyboard checking is just starting
      psychoJS.window.callOnFlip(function() { key_resp_4.clock.reset(); });  // t=0 on next screen flip
      psychoJS.window.callOnFlip(function() { key_resp_4.start(); }); // start on screen flip
      psychoJS.window.callOnFlip(function() { key_resp_4.clearEvents(); });
    }

    if (key_resp_4.status === PsychoJS.Status.STARTED) {
      let theseKeys = key_resp_4.getKeys({keyList: ['space'], waitRelease: false});
      _key_resp_4_allKeys = _key_resp_4_allKeys.concat(theseKeys);
      if (_key_resp_4_allKeys.length > 0) {
        key_resp_4.keys = _key_resp_4_allKeys[_key_resp_4_allKeys.length - 1].name;  // just the last key pressed
        key_resp_4.rt = _key_resp_4_allKeys[_key_resp_4_allKeys.length - 1].rt;
        // a response ends the routine
        continueRoutine = false;
      }
    }
    
    
    // *go_on* updates
    if (t >= 1.0 && go_on.status === PsychoJS.Status.NOT_STARTED) {
      // keep track of start time/frame for later
      go_on.tStart = t;  // (not accounting for frame time here)
      go_on.frameNStart = frameN;  // exact frame index
      
      go_on.setAutoDraw(true);
    }

    
    // *text_typicality* updates
    if (t >= 0.0 && text_typicality.status === PsychoJS.Status.NOT_STARTED) {
      // keep track of start time/frame for later
      text_typicality.tStart = t;  // (not accounting for frame time here)
      text_typicality.frameNStart = frameN;  // exact frame index
      
      text_typicality.setAutoDraw(true);
    }

    
    // *text_sliding_scale* updates
    if (t >= 0.0 && text_sliding_scale.status === PsychoJS.Status.NOT_STARTED) {
      // keep track of start time/frame for later
      text_sliding_scale.tStart = t;  // (not accounting for frame time here)
      text_sliding_scale.frameNStart = frameN;  // exact frame index
      
      text_sliding_scale.setAutoDraw(true);
    }

    // check for quit (typically the Esc key)
    if (psychoJS.experiment.experimentEnded || psychoJS.eventManager.getKeys({keyList:['escape']}).length > 0) {
      return quitPsychoJS('The [Escape] key was pressed. Goodbye!', false);
    }
    
    // check if the Routine should terminate
    if (!continueRoutine) {  // a component has requested a forced-end of Routine
      return Scheduler.Event.NEXT;
    }
    
    continueRoutine = false;  // reverts to True if at least one component still running
    for (const thisComponent of general_infoComponents)
      if ('status' in thisComponent && thisComponent.status !== PsychoJS.Status.FINISHED) {
        continueRoutine = true;
        break;
      }
    
    // refresh the screen if continuing
    if (continueRoutine) {
      return Scheduler.Event.FLIP_REPEAT;
    } else {
      return Scheduler.Event.NEXT;
    }
  };
}


function general_infoRoutineEnd(snapshot) {
  return function () {
    //------Ending Routine 'general_info'-------
    for (const thisComponent of general_infoComponents) {
      if (typeof thisComponent.setAutoDraw === 'function') {
        thisComponent.setAutoDraw(false);
      }
    }
    key_resp_4.stop();
    // the Routine "general_info" was not non-slip safe, so reset the non-slip timer
    routineTimer.reset();
    
    return Scheduler.Event.NEXT;
  };
}


var _key_resp_allKeys;
var _key_resp_9_allKeys;
var specific_instructionsComponents;
function specific_instructionsRoutineBegin(snapshot) {
  return function () {
    //------Prepare to start Routine 'specific_instructions'-------
    t = 0;
    specific_instructionsClock.reset(); // clock
    frameN = -1;
    continueRoutine = true; // until we're told otherwise
    // update component parameters for each repeat
    key_resp.keys = undefined;
    key_resp.rt = undefined;
    _key_resp_allKeys = [];
    text_instructions.setAlignHoriz('left');
    key_resp_9.keys = undefined;
    key_resp_9.rt = undefined;
    _key_resp_9_allKeys = [];
    // keep track of which components have finished
    specific_instructionsComponents = [];
    specific_instructionsComponents.push(text_instructions);
    specific_instructionsComponents.push(key_resp);
    specific_instructionsComponents.push(space_go_on);
    specific_instructionsComponents.push(left_arrow);
    specific_instructionsComponents.push(key_resp_9);
    
    for (const thisComponent of specific_instructionsComponents)
      if ('status' in thisComponent)
        thisComponent.status = PsychoJS.Status.NOT_STARTED;
    return Scheduler.Event.NEXT;
  }
}


function specific_instructionsRoutineEachFrame(snapshot) {
  return function () {
    //------Loop for each frame of Routine 'specific_instructions'-------
    // get current time
    t = specific_instructionsClock.getTime();
    frameN = frameN + 1;// number of completed frames (so 0 is the first frame)
    // update/draw components on each frame
    
    // *text_instructions* updates
    if (t >= 0.0 && text_instructions.status === PsychoJS.Status.NOT_STARTED) {
      // keep track of start time/frame for later
      text_instructions.tStart = t;  // (not accounting for frame time here)
      text_instructions.frameNStart = frameN;  // exact frame index
      
      text_instructions.setAutoDraw(true);
    }

    
    // *key_resp* updates
    if (t >= 0.0 && key_resp.status === PsychoJS.Status.NOT_STARTED) {
      // keep track of start time/frame for later
      key_resp.tStart = t;  // (not accounting for frame time here)
      key_resp.frameNStart = frameN;  // exact frame index
      
      // keyboard checking is just starting
      psychoJS.window.callOnFlip(function() { key_resp.clock.reset(); });  // t=0 on next screen flip
      psychoJS.window.callOnFlip(function() { key_resp.start(); }); // start on screen flip
      psychoJS.window.callOnFlip(function() { key_resp.clearEvents(); });
    }

    if (key_resp.status === PsychoJS.Status.STARTED) {
      let theseKeys = key_resp.getKeys({keyList: ['left'], waitRelease: false});
      _key_resp_allKeys = _key_resp_allKeys.concat(theseKeys);
      if (_key_resp_allKeys.length > 0) {
        key_resp.keys = _key_resp_allKeys[_key_resp_allKeys.length - 1].name;  // just the last key pressed
        key_resp.rt = _key_resp_allKeys[_key_resp_allKeys.length - 1].rt;
        // a response ends the routine
        continueRoutine = false;
      }
    }
    
    
    // *space_go_on* updates
    if (t >= 1.0 && space_go_on.status === PsychoJS.Status.NOT_STARTED) {
      // keep track of start time/frame for later
      space_go_on.tStart = t;  // (not accounting for frame time here)
      space_go_on.frameNStart = frameN;  // exact frame index
      
      space_go_on.setAutoDraw(true);
    }

    
    // *left_arrow* updates
    if (t >= 1.0 && left_arrow.status === PsychoJS.Status.NOT_STARTED) {
      // keep track of start time/frame for later
      left_arrow.tStart = t;  // (not accounting for frame time here)
      left_arrow.frameNStart = frameN;  // exact frame index
      
      left_arrow.setAutoDraw(true);
    }

    
    // *key_resp_9* updates
    if (t >= 0.0 && key_resp_9.status === PsychoJS.Status.NOT_STARTED) {
      // keep track of start time/frame for later
      key_resp_9.tStart = t;  // (not accounting for frame time here)
      key_resp_9.frameNStart = frameN;  // exact frame index
      
      // keyboard checking is just starting
      psychoJS.window.callOnFlip(function() { key_resp_9.clock.reset(); });  // t=0 on next screen flip
      psychoJS.window.callOnFlip(function() { key_resp_9.start(); }); // start on screen flip
      psychoJS.window.callOnFlip(function() { key_resp_9.clearEvents(); });
    }

    if (key_resp_9.status === PsychoJS.Status.STARTED) {
      let theseKeys = key_resp_9.getKeys({keyList: ['space'], waitRelease: false});
      _key_resp_9_allKeys = _key_resp_9_allKeys.concat(theseKeys);
      if (_key_resp_9_allKeys.length > 0) {
        key_resp_9.keys = _key_resp_9_allKeys[_key_resp_9_allKeys.length - 1].name;  // just the last key pressed
        key_resp_9.rt = _key_resp_9_allKeys[_key_resp_9_allKeys.length - 1].rt;
        // a response ends the routine
        continueRoutine = false;
      }
    }
    
    // check for quit (typically the Esc key)
    if (psychoJS.experiment.experimentEnded || psychoJS.eventManager.getKeys({keyList:['escape']}).length > 0) {
      return quitPsychoJS('The [Escape] key was pressed. Goodbye!', false);
    }
    
    // check if the Routine should terminate
    if (!continueRoutine) {  // a component has requested a forced-end of Routine
      return Scheduler.Event.NEXT;
    }
    
    continueRoutine = false;  // reverts to True if at least one component still running
    for (const thisComponent of specific_instructionsComponents)
      if ('status' in thisComponent && thisComponent.status !== PsychoJS.Status.FINISHED) {
        continueRoutine = true;
        break;
      }
    
    // refresh the screen if continuing
    if (continueRoutine) {
      return Scheduler.Event.FLIP_REPEAT;
    } else {
      return Scheduler.Event.NEXT;
    }
  };
}


function specific_instructionsRoutineEnd(snapshot) {
  return function () {
    //------Ending Routine 'specific_instructions'-------
    for (const thisComponent of specific_instructionsComponents) {
      if (typeof thisComponent.setAutoDraw === 'function') {
        thisComponent.setAutoDraw(false);
      }
    }
    key_resp.stop();
    psychoJS.experiment.addData('key_resp_9.keys', key_resp_9.keys);
    if (typeof key_resp_9.keys !== 'undefined') {  // we had a response
        psychoJS.experiment.addData('key_resp_9.rt', key_resp_9.rt);
        routineTimer.reset();
        }
    
    key_resp_9.stop();
    if ((key_resp_9.keys === "space")) {
        come_back.finished = true;
    }
    
    // the Routine "specific_instructions" was not non-slip safe, so reset the non-slip timer
    routineTimer.reset();
    
    return Scheduler.Event.NEXT;
  };
}


var _key_resp_6_allKeys;
var trialComponents;
function trialRoutineBegin(snapshot) {
  return function () {
    //------Prepare to start Routine 'trial'-------
    t = 0;
    trialClock.reset(); // clock
    frameN = -1;
    continueRoutine = true; // until we're told otherwise
    // update component parameters for each repeat
    image_2.setImage(imageFam);
    slider_2.reset()
    key_resp_6.keys = undefined;
    key_resp_6.rt = undefined;
    _key_resp_6_allKeys = [];
    text_4.setText(category);
    // keep track of which components have finished
    trialComponents = [];
    trialComponents.push(image_2);
    trialComponents.push(slider_2);
    trialComponents.push(key_resp_6);
    trialComponents.push(text_4);
    trialComponents.push(once_judged);
    
    for (const thisComponent of trialComponents)
      if ('status' in thisComponent)
        thisComponent.status = PsychoJS.Status.NOT_STARTED;
    return Scheduler.Event.NEXT;
  }
}


function trialRoutineEachFrame(snapshot) {
  return function () {
    //------Loop for each frame of Routine 'trial'-------
    // get current time
    t = trialClock.getTime();
    frameN = frameN + 1;// number of completed frames (so 0 is the first frame)
    // update/draw components on each frame
    
    // *image_2* updates
    if (t >= 0.0 && image_2.status === PsychoJS.Status.NOT_STARTED) {
      // keep track of start time/frame for later
      image_2.tStart = t;  // (not accounting for frame time here)
      image_2.frameNStart = frameN;  // exact frame index
      
      image_2.setAutoDraw(true);
    }

    
    // *slider_2* updates
    if (t >= 1.0 && slider_2.status === PsychoJS.Status.NOT_STARTED) {
      // keep track of start time/frame for later
      slider_2.tStart = t;  // (not accounting for frame time here)
      slider_2.frameNStart = frameN;  // exact frame index
      
      slider_2.setAutoDraw(true);
    }

    
    // *key_resp_6* updates
    if (t >= 1.0 && key_resp_6.status === PsychoJS.Status.NOT_STARTED) {
      // keep track of start time/frame for later
      key_resp_6.tStart = t;  // (not accounting for frame time here)
      key_resp_6.frameNStart = frameN;  // exact frame index
      
      // keyboard checking is just starting
      psychoJS.window.callOnFlip(function() { key_resp_6.clock.reset(); });  // t=0 on next screen flip
      psychoJS.window.callOnFlip(function() { key_resp_6.start(); }); // start on screen flip
      psychoJS.window.callOnFlip(function() { key_resp_6.clearEvents(); });
    }

    if (key_resp_6.status === PsychoJS.Status.STARTED) {
      let theseKeys = key_resp_6.getKeys({keyList: ['space'], waitRelease: false});
      _key_resp_6_allKeys = _key_resp_6_allKeys.concat(theseKeys);
      if (_key_resp_6_allKeys.length > 0) {
        key_resp_6.keys = _key_resp_6_allKeys[_key_resp_6_allKeys.length - 1].name;  // just the last key pressed
        key_resp_6.rt = _key_resp_6_allKeys[_key_resp_6_allKeys.length - 1].rt;
        // a response ends the routine
        continueRoutine = false;
      }
    }
    
    
    // *text_4* updates
    if (t >= 1.0 && text_4.status === PsychoJS.Status.NOT_STARTED) {
      // keep track of start time/frame for later
      text_4.tStart = t;  // (not accounting for frame time here)
      text_4.frameNStart = frameN;  // exact frame index
      
      text_4.setAutoDraw(true);
    }

    
    // *once_judged* updates
    if (t >= 1.0 && once_judged.status === PsychoJS.Status.NOT_STARTED) {
      // keep track of start time/frame for later
      once_judged.tStart = t;  // (not accounting for frame time here)
      once_judged.frameNStart = frameN;  // exact frame index
      
      once_judged.setAutoDraw(true);
    }

    // check for quit (typically the Esc key)
    if (psychoJS.experiment.experimentEnded || psychoJS.eventManager.getKeys({keyList:['escape']}).length > 0) {
      return quitPsychoJS('The [Escape] key was pressed. Goodbye!', false);
    }
    
    // check if the Routine should terminate
    if (!continueRoutine) {  // a component has requested a forced-end of Routine
      return Scheduler.Event.NEXT;
    }
    
    continueRoutine = false;  // reverts to True if at least one component still running
    for (const thisComponent of trialComponents)
      if ('status' in thisComponent && thisComponent.status !== PsychoJS.Status.FINISHED) {
        continueRoutine = true;
        break;
      }
    
    // refresh the screen if continuing
    if (continueRoutine) {
      return Scheduler.Event.FLIP_REPEAT;
    } else {
      return Scheduler.Event.NEXT;
    }
  };
}


function trialRoutineEnd(snapshot) {
  return function () {
    //------Ending Routine 'trial'-------
    for (const thisComponent of trialComponents) {
      if (typeof thisComponent.setAutoDraw === 'function') {
        thisComponent.setAutoDraw(false);
      }
    }
    psychoJS.experiment.addData('slider_2.response', slider_2.getRating());
    psychoJS.experiment.addData('slider_2.rt', slider_2.getRT());
    psychoJS.experiment.addData('key_resp_6.keys', key_resp_6.keys);
    if (typeof key_resp_6.keys !== 'undefined') {  // we had a response
        psychoJS.experiment.addData('key_resp_6.rt', key_resp_6.rt);
        routineTimer.reset();
        }
    
    key_resp_6.stop();
    // the Routine "trial" was not non-slip safe, so reset the non-slip timer
    routineTimer.reset();
    
    return Scheduler.Event.NEXT;
  };
}


var _key_resp_7_allKeys;
var start_expComponents;
function start_expRoutineBegin(snapshot) {
  return function () {
    //------Prepare to start Routine 'start_exp'-------
    t = 0;
    start_expClock.reset(); // clock
    frameN = -1;
    continueRoutine = true; // until we're told otherwise
    // update component parameters for each repeat
    key_resp_7.keys = undefined;
    key_resp_7.rt = undefined;
    _key_resp_7_allKeys = [];
    // keep track of which components have finished
    start_expComponents = [];
    start_expComponents.push(text_start_exp);
    start_expComponents.push(key_resp_7);
    
    for (const thisComponent of start_expComponents)
      if ('status' in thisComponent)
        thisComponent.status = PsychoJS.Status.NOT_STARTED;
    return Scheduler.Event.NEXT;
  }
}


function start_expRoutineEachFrame(snapshot) {
  return function () {
    //------Loop for each frame of Routine 'start_exp'-------
    // get current time
    t = start_expClock.getTime();
    frameN = frameN + 1;// number of completed frames (so 0 is the first frame)
    // update/draw components on each frame
    
    // *text_start_exp* updates
    if (t >= 0.0 && text_start_exp.status === PsychoJS.Status.NOT_STARTED) {
      // keep track of start time/frame for later
      text_start_exp.tStart = t;  // (not accounting for frame time here)
      text_start_exp.frameNStart = frameN;  // exact frame index
      
      text_start_exp.setAutoDraw(true);
    }

    
    // *key_resp_7* updates
    if (t >= 0.0 && key_resp_7.status === PsychoJS.Status.NOT_STARTED) {
      // keep track of start time/frame for later
      key_resp_7.tStart = t;  // (not accounting for frame time here)
      key_resp_7.frameNStart = frameN;  // exact frame index
      
      // keyboard checking is just starting
      psychoJS.window.callOnFlip(function() { key_resp_7.clock.reset(); });  // t=0 on next screen flip
      psychoJS.window.callOnFlip(function() { key_resp_7.start(); }); // start on screen flip
      psychoJS.window.callOnFlip(function() { key_resp_7.clearEvents(); });
    }

    if (key_resp_7.status === PsychoJS.Status.STARTED) {
      let theseKeys = key_resp_7.getKeys({keyList: ['space'], waitRelease: false});
      _key_resp_7_allKeys = _key_resp_7_allKeys.concat(theseKeys);
      if (_key_resp_7_allKeys.length > 0) {
        key_resp_7.keys = _key_resp_7_allKeys[_key_resp_7_allKeys.length - 1].name;  // just the last key pressed
        key_resp_7.rt = _key_resp_7_allKeys[_key_resp_7_allKeys.length - 1].rt;
        // a response ends the routine
        continueRoutine = false;
      }
    }
    
    // check for quit (typically the Esc key)
    if (psychoJS.experiment.experimentEnded || psychoJS.eventManager.getKeys({keyList:['escape']}).length > 0) {
      return quitPsychoJS('The [Escape] key was pressed. Goodbye!', false);
    }
    
    // check if the Routine should terminate
    if (!continueRoutine) {  // a component has requested a forced-end of Routine
      return Scheduler.Event.NEXT;
    }
    
    continueRoutine = false;  // reverts to True if at least one component still running
    for (const thisComponent of start_expComponents)
      if ('status' in thisComponent && thisComponent.status !== PsychoJS.Status.FINISHED) {
        continueRoutine = true;
        break;
      }
    
    // refresh the screen if continuing
    if (continueRoutine) {
      return Scheduler.Event.FLIP_REPEAT;
    } else {
      return Scheduler.Event.NEXT;
    }
  };
}


function start_expRoutineEnd(snapshot) {
  return function () {
    //------Ending Routine 'start_exp'-------
    for (const thisComponent of start_expComponents) {
      if (typeof thisComponent.setAutoDraw === 'function') {
        thisComponent.setAutoDraw(false);
      }
    }
    key_resp_7.stop();
    // the Routine "start_exp" was not non-slip safe, so reset the non-slip timer
    routineTimer.reset();
    
    return Scheduler.Event.NEXT;
  };
}


var _key_resp_2_allKeys;
var real_experimentComponents;
function real_experimentRoutineBegin(snapshot) {
  return function () {
    //------Prepare to start Routine 'real_experiment'-------
    t = 0;
    real_experimentClock.reset(); // clock
    frameN = -1;
    continueRoutine = true; // until we're told otherwise
    // update component parameters for each repeat
    image_stimuli.setImage(image);
    slider.reset()
    text.setText(topName);
    key_resp_2.keys = undefined;
    key_resp_2.rt = undefined;
    _key_resp_2_allKeys = [];
    // keep track of which components have finished
    real_experimentComponents = [];
    real_experimentComponents.push(image_stimuli);
    real_experimentComponents.push(slider);
    real_experimentComponents.push(text);
    real_experimentComponents.push(key_resp_2);
    real_experimentComponents.push(once_judged_2);
    
    for (const thisComponent of real_experimentComponents)
      if ('status' in thisComponent)
        thisComponent.status = PsychoJS.Status.NOT_STARTED;
    return Scheduler.Event.NEXT;
  }
}


function real_experimentRoutineEachFrame(snapshot) {
  return function () {
    //------Loop for each frame of Routine 'real_experiment'-------
    // get current time
    t = real_experimentClock.getTime();
    frameN = frameN + 1;// number of completed frames (so 0 is the first frame)
    // update/draw components on each frame
    
    // *image_stimuli* updates
    if (t >= 0.0 && image_stimuli.status === PsychoJS.Status.NOT_STARTED) {
      // keep track of start time/frame for later
      image_stimuli.tStart = t;  // (not accounting for frame time here)
      image_stimuli.frameNStart = frameN;  // exact frame index
      
      image_stimuli.setAutoDraw(true);
    }

    
    // *slider* updates
    if (t >= 1.0 && slider.status === PsychoJS.Status.NOT_STARTED) {
      // keep track of start time/frame for later
      slider.tStart = t;  // (not accounting for frame time here)
      slider.frameNStart = frameN;  // exact frame index
      
      slider.setAutoDraw(true);
    }

    
    // *text* updates
    if (t >= 1.0 && text.status === PsychoJS.Status.NOT_STARTED) {
      // keep track of start time/frame for later
      text.tStart = t;  // (not accounting for frame time here)
      text.frameNStart = frameN;  // exact frame index
      
      text.setAutoDraw(true);
    }

    
    // *key_resp_2* updates
    if (t >= 1.0 && key_resp_2.status === PsychoJS.Status.NOT_STARTED) {
      // keep track of start time/frame for later
      key_resp_2.tStart = t;  // (not accounting for frame time here)
      key_resp_2.frameNStart = frameN;  // exact frame index
      
      // keyboard checking is just starting
      psychoJS.window.callOnFlip(function() { key_resp_2.clock.reset(); });  // t=0 on next screen flip
      psychoJS.window.callOnFlip(function() { key_resp_2.start(); }); // start on screen flip
      psychoJS.window.callOnFlip(function() { key_resp_2.clearEvents(); });
    }

    if (key_resp_2.status === PsychoJS.Status.STARTED) {
      let theseKeys = key_resp_2.getKeys({keyList: ['space'], waitRelease: false});
      _key_resp_2_allKeys = _key_resp_2_allKeys.concat(theseKeys);
      if (_key_resp_2_allKeys.length > 0) {
        key_resp_2.keys = _key_resp_2_allKeys[_key_resp_2_allKeys.length - 1].name;  // just the last key pressed
        key_resp_2.rt = _key_resp_2_allKeys[_key_resp_2_allKeys.length - 1].rt;
        // a response ends the routine
        continueRoutine = false;
      }
    }
    
    
    // *once_judged_2* updates
    if (t >= 1.0 && once_judged_2.status === PsychoJS.Status.NOT_STARTED) {
      // keep track of start time/frame for later
      once_judged_2.tStart = t;  // (not accounting for frame time here)
      once_judged_2.frameNStart = frameN;  // exact frame index
      
      once_judged_2.setAutoDraw(true);
    }

    // check for quit (typically the Esc key)
    if (psychoJS.experiment.experimentEnded || psychoJS.eventManager.getKeys({keyList:['escape']}).length > 0) {
      return quitPsychoJS('The [Escape] key was pressed. Goodbye!', false);
    }
    
    // check if the Routine should terminate
    if (!continueRoutine) {  // a component has requested a forced-end of Routine
      return Scheduler.Event.NEXT;
    }
    
    continueRoutine = false;  // reverts to True if at least one component still running
    for (const thisComponent of real_experimentComponents)
      if ('status' in thisComponent && thisComponent.status !== PsychoJS.Status.FINISHED) {
        continueRoutine = true;
        break;
      }
    
    // refresh the screen if continuing
    if (continueRoutine) {
      return Scheduler.Event.FLIP_REPEAT;
    } else {
      return Scheduler.Event.NEXT;
    }
  };
}


function real_experimentRoutineEnd(snapshot) {
  return function () {
    //------Ending Routine 'real_experiment'-------
    for (const thisComponent of real_experimentComponents) {
      if (typeof thisComponent.setAutoDraw === 'function') {
        thisComponent.setAutoDraw(false);
      }
    }
    psychoJS.experiment.addData('slider.response', slider.getRating());
    psychoJS.experiment.addData('slider.rt', slider.getRT());
    psychoJS.experiment.addData('key_resp_2.keys', key_resp_2.keys);
    if (typeof key_resp_2.keys !== 'undefined') {  // we had a response
        psychoJS.experiment.addData('key_resp_2.rt', key_resp_2.rt);
        routineTimer.reset();
        }
    
    key_resp_2.stop();
    // the Routine "real_experiment" was not non-slip safe, so reset the non-slip timer
    routineTimer.reset();
    
    return Scheduler.Event.NEXT;
  };
}


var _end_experiment_allKeys;
var final_commentsComponents;
function final_commentsRoutineBegin(snapshot) {
  return function () {
    //------Prepare to start Routine 'final_comments'-------
    t = 0;
    final_commentsClock.reset(); // clock
    frameN = -1;
    continueRoutine = true; // until we're told otherwise
    // update component parameters for each repeat
    end_experiment.keys = undefined;
    end_experiment.rt = undefined;
    _end_experiment_allKeys = [];
    // keep track of which components have finished
    final_commentsComponents = [];
    final_commentsComponents.push(leave_comment);
    final_commentsComponents.push(textbox);
    final_commentsComponents.push(rigth_arrow);
    final_commentsComponents.push(end_experiment);
    
    for (const thisComponent of final_commentsComponents)
      if ('status' in thisComponent)
        thisComponent.status = PsychoJS.Status.NOT_STARTED;
    return Scheduler.Event.NEXT;
  }
}


function final_commentsRoutineEachFrame(snapshot) {
  return function () {
    //------Loop for each frame of Routine 'final_comments'-------
    // get current time
    t = final_commentsClock.getTime();
    frameN = frameN + 1;// number of completed frames (so 0 is the first frame)
    // update/draw components on each frame
    
    // *leave_comment* updates
    if (t >= 0.0 && leave_comment.status === PsychoJS.Status.NOT_STARTED) {
      // keep track of start time/frame for later
      leave_comment.tStart = t;  // (not accounting for frame time here)
      leave_comment.frameNStart = frameN;  // exact frame index
      
      leave_comment.setAutoDraw(true);
    }

    
    // *textbox* updates
    if (t >= 0.0 && textbox.status === PsychoJS.Status.NOT_STARTED) {
      // keep track of start time/frame for later
      textbox.tStart = t;  // (not accounting for frame time here)
      textbox.frameNStart = frameN;  // exact frame index
      
      textbox.setAutoDraw(true);
    }

    
    // *rigth_arrow* updates
    if (t >= 0.0 && rigth_arrow.status === PsychoJS.Status.NOT_STARTED) {
      // keep track of start time/frame for later
      rigth_arrow.tStart = t;  // (not accounting for frame time here)
      rigth_arrow.frameNStart = frameN;  // exact frame index
      
      rigth_arrow.setAutoDraw(true);
    }

    
    // *end_experiment* updates
    if (t >= 0.0 && end_experiment.status === PsychoJS.Status.NOT_STARTED) {
      // keep track of start time/frame for later
      end_experiment.tStart = t;  // (not accounting for frame time here)
      end_experiment.frameNStart = frameN;  // exact frame index
      
      // keyboard checking is just starting
      psychoJS.window.callOnFlip(function() { end_experiment.clock.reset(); });  // t=0 on next screen flip
      psychoJS.window.callOnFlip(function() { end_experiment.start(); }); // start on screen flip
      psychoJS.window.callOnFlip(function() { end_experiment.clearEvents(); });
    }

    if (end_experiment.status === PsychoJS.Status.STARTED) {
      let theseKeys = end_experiment.getKeys({keyList: ['right'], waitRelease: false});
      _end_experiment_allKeys = _end_experiment_allKeys.concat(theseKeys);
      if (_end_experiment_allKeys.length > 0) {
        end_experiment.keys = _end_experiment_allKeys[_end_experiment_allKeys.length - 1].name;  // just the last key pressed
        end_experiment.rt = _end_experiment_allKeys[_end_experiment_allKeys.length - 1].rt;
        // a response ends the routine
        continueRoutine = false;
      }
    }
    
    // check for quit (typically the Esc key)
    if (psychoJS.experiment.experimentEnded || psychoJS.eventManager.getKeys({keyList:['escape']}).length > 0) {
      return quitPsychoJS('The [Escape] key was pressed. Goodbye!', false);
    }
    
    // check if the Routine should terminate
    if (!continueRoutine) {  // a component has requested a forced-end of Routine
      return Scheduler.Event.NEXT;
    }
    
    continueRoutine = false;  // reverts to True if at least one component still running
    for (const thisComponent of final_commentsComponents)
      if ('status' in thisComponent && thisComponent.status !== PsychoJS.Status.FINISHED) {
        continueRoutine = true;
        break;
      }
    
    // refresh the screen if continuing
    if (continueRoutine) {
      return Scheduler.Event.FLIP_REPEAT;
    } else {
      return Scheduler.Event.NEXT;
    }
  };
}


function final_commentsRoutineEnd(snapshot) {
  return function () {
    //------Ending Routine 'final_comments'-------
    for (const thisComponent of final_commentsComponents) {
      if (typeof thisComponent.setAutoDraw === 'function') {
        thisComponent.setAutoDraw(false);
      }
    }
    psychoJS.experiment.addData('textbox.text',textbox.text)
    textbox.reset()
    end_experiment.stop();
    // the Routine "final_comments" was not non-slip safe, so reset the non-slip timer
    routineTimer.reset();
    
    return Scheduler.Event.NEXT;
  };
}


var _key_resp_10_allKeys;
var thanks_messageComponents;
function thanks_messageRoutineBegin(snapshot) {
  return function () {
    //------Prepare to start Routine 'thanks_message'-------
    t = 0;
    thanks_messageClock.reset(); // clock
    frameN = -1;
    continueRoutine = true; // until we're told otherwise
    // update component parameters for each repeat
    key_resp_10.keys = undefined;
    key_resp_10.rt = undefined;
    _key_resp_10_allKeys = [];
    // keep track of which components have finished
    thanks_messageComponents = [];
    thanks_messageComponents.push(thanks_text);
    thanks_messageComponents.push(key_resp_10);
    
    for (const thisComponent of thanks_messageComponents)
      if ('status' in thisComponent)
        thisComponent.status = PsychoJS.Status.NOT_STARTED;
    return Scheduler.Event.NEXT;
  }
}


function thanks_messageRoutineEachFrame(snapshot) {
  return function () {
    //------Loop for each frame of Routine 'thanks_message'-------
    // get current time
    t = thanks_messageClock.getTime();
    frameN = frameN + 1;// number of completed frames (so 0 is the first frame)
    // update/draw components on each frame
    
    // *thanks_text* updates
    if (t >= 0.0 && thanks_text.status === PsychoJS.Status.NOT_STARTED) {
      // keep track of start time/frame for later
      thanks_text.tStart = t;  // (not accounting for frame time here)
      thanks_text.frameNStart = frameN;  // exact frame index
      
      thanks_text.setAutoDraw(true);
    }

    
    // *key_resp_10* updates
    if (t >= 0.0 && key_resp_10.status === PsychoJS.Status.NOT_STARTED) {
      // keep track of start time/frame for later
      key_resp_10.tStart = t;  // (not accounting for frame time here)
      key_resp_10.frameNStart = frameN;  // exact frame index
      
      // keyboard checking is just starting
      psychoJS.window.callOnFlip(function() { key_resp_10.clock.reset(); });  // t=0 on next screen flip
      psychoJS.window.callOnFlip(function() { key_resp_10.start(); }); // start on screen flip
      psychoJS.window.callOnFlip(function() { key_resp_10.clearEvents(); });
    }

    if (key_resp_10.status === PsychoJS.Status.STARTED) {
      let theseKeys = key_resp_10.getKeys({keyList: ['space'], waitRelease: false});
      _key_resp_10_allKeys = _key_resp_10_allKeys.concat(theseKeys);
      if (_key_resp_10_allKeys.length > 0) {
        key_resp_10.keys = _key_resp_10_allKeys[_key_resp_10_allKeys.length - 1].name;  // just the last key pressed
        key_resp_10.rt = _key_resp_10_allKeys[_key_resp_10_allKeys.length - 1].rt;
        // a response ends the routine
        continueRoutine = false;
      }
    }
    
    // check for quit (typically the Esc key)
    if (psychoJS.experiment.experimentEnded || psychoJS.eventManager.getKeys({keyList:['escape']}).length > 0) {
      return quitPsychoJS('The [Escape] key was pressed. Goodbye!', false);
    }
    
    // check if the Routine should terminate
    if (!continueRoutine) {  // a component has requested a forced-end of Routine
      return Scheduler.Event.NEXT;
    }
    
    continueRoutine = false;  // reverts to True if at least one component still running
    for (const thisComponent of thanks_messageComponents)
      if ('status' in thisComponent && thisComponent.status !== PsychoJS.Status.FINISHED) {
        continueRoutine = true;
        break;
      }
    
    // refresh the screen if continuing
    if (continueRoutine) {
      return Scheduler.Event.FLIP_REPEAT;
    } else {
      return Scheduler.Event.NEXT;
    }
  };
}


function thanks_messageRoutineEnd(snapshot) {
  return function () {
    //------Ending Routine 'thanks_message'-------
    for (const thisComponent of thanks_messageComponents) {
      if (typeof thisComponent.setAutoDraw === 'function') {
        thisComponent.setAutoDraw(false);
      }
    }
    psychoJS.experiment.addData('key_resp_10.keys', key_resp_10.keys);
    if (typeof key_resp_10.keys !== 'undefined') {  // we had a response
        psychoJS.experiment.addData('key_resp_10.rt', key_resp_10.rt);
        routineTimer.reset();
        }
    
    key_resp_10.stop();
    // the Routine "thanks_message" was not non-slip safe, so reset the non-slip timer
    routineTimer.reset();
    
    return Scheduler.Event.NEXT;
  };
}


function endLoopIteration(scheduler, snapshot) {
  // ------Prepare for next entry------
  return function () {
    if (typeof snapshot !== 'undefined') {
      // ------Check if user ended loop early------
      if (snapshot.finished) {
        // Check for and save orphaned data
        if (psychoJS.experiment.isEntryEmpty()) {
          psychoJS.experiment.nextEntry(snapshot);
        }
        scheduler.stop();
      } else {
        const thisTrial = snapshot.getCurrentTrial();
        if (typeof thisTrial === 'undefined' || !('isTrials' in thisTrial) || thisTrial.isTrials) {
          psychoJS.experiment.nextEntry(snapshot);
        }
      }
    return Scheduler.Event.NEXT;
    }
  };
}


function importConditions(currentLoop) {
  return function () {
    psychoJS.importAttributes(currentLoop.getCurrentTrial());
    return Scheduler.Event.NEXT;
    };
}


function quitPsychoJS(message, isCompleted) {
  // Check for and save orphaned data
  if (psychoJS.experiment.isEntryEmpty()) {
    psychoJS.experiment.nextEntry();
  }
  
  
  
  
  
  
  
  
  
  
  psychoJS.window.close();
  psychoJS.quit({message: message, isCompleted: isCompleted});
  
  return Scheduler.Event.QUIT;
}
